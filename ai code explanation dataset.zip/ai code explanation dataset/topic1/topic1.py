import os
import json

input_folder = "topic1"   # your folder name

for filename in os.listdir(input_folder):
    if filename.endswith(".txt"):
        input_path = os.path.join(input_folder, filename)
        output_path = os.path.join(input_folder, filename.replace(".txt", ".json"))

        data = []

        with open(input_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    data.append(json.loads(line))

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)

        print(f"Converted: {filename} → {filename.replace('.txt', '.json')}")

print("✅ All files converted!")