import os
import json

# Path to main folder
main_folder = "AI_Code_Explanation_Dataset"

# Loop through each topic folder
for folder_name in os.listdir(main_folder):
    folder_path = os.path.join(main_folder, folder_name)
    
    if os.path.isdir(folder_path):
        combined_data = []

        # Loop through all JSON files in the folder
        for file_name in os.listdir(folder_path):
            if file_name.endswith(".json"):
                file_path = os.path.join(folder_path, file_name)

                with open(file_path, "r", encoding="utf-8") as f:
                    try:
                        data = json.load(f)

                        # If JSON is a list → extend
                        if isinstance(data, list):
                            combined_data.extend(data)
                        else:
                            combined_data.append(data)

                    except json.JSONDecodeError:
                        print(f"Error reading {file_path}")

        # Save combined file
        output_file = os.path.join(folder_path, f"{folder_name}_combined.json")

        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(combined_data, f, indent=4, ensure_ascii=False)

        print(f"✅ Combined file created: {output_file}")